package com.dcmomis.order.service;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.dcmomis.common.ResponseBean;
import com.dcmomis.order.OrderRecordBean;
import com.dcmomis.utils.DBUtils;
import com.dcmomis.utils.StringUtils;

public class OrderOperationDao {
	public static String placeOrderRecord(OrderRecordBean orb) {
		// ���
		Connection conn = null;
		PreparedStatement pstm = null;
		ResponseBean rb = new ResponseBean();
		String sqlInsert = "INSERT INTO `bd_dw_dcm_order_record` "
				+ "(ORDER_DATE, GROUP_ID, CST_ID, LINK, COMMODITY_NAME, "
				+ "COMMODITY_DESC, UNIT_PRICE, AMOUNT, GOODS_COLOR, " + "GOODS_SIZE, DISCOUNT_1, COMMENTS, PICTURE) "
				+ "VALUES " + "( '20160328',?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			conn = DBUtils.getDBConnection();
			pstm = conn.prepareStatement(sqlInsert);
			pstm.setString(1, orb.getGroupId());
			pstm.setString(2, orb.getCstId());
			pstm.setString(3, orb.getLink());
			pstm.setString(4, orb.getCommodityName());
			pstm.setString(5, orb.getCommodityDesc());
			pstm.setString(6, orb.getUnitPrice());
			pstm.setString(7, orb.getAmount());
			pstm.setString(8, orb.getGoodsColor());
			pstm.setString(9, orb.getGoodsSize());
			pstm.setString(10, orb.getDiscount1());
			pstm.setString(11, orb.getComments());
			pstm.setString(12, orb.getPicture());
			pstm.addBatch();
			// ArrayList columnNames=new ArrayList();
			pstm.executeBatch();
			// return customerInfoList;
		} catch (Exception e) {
			e.printStackTrace();
			rb.setErrorMsg("������");
			rb.setSuccess(false);
			String result = StringUtils.listToJson(rb, false);
			return result;
		} finally {
			DBUtils.release(pstm, null, conn);
		}
			rb.setSuccessMsg("�µ��ɹ�,�Ƿ���ת������������");
			rb.setSuccess(true);

		String result = StringUtils.listToJson(rb, false);
		return result;
	}
}
