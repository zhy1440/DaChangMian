package com.dcmomis.user;

public class CustomerInfoBean {
	private String userId;
	private String memberLevel;
	private String exchangRate;
	private String commonAddr;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getMemberLevel() {
		return memberLevel;
	}
	public void setMemberLevel(String memberLevel) {
		this.memberLevel = memberLevel;
	}
	public String getExchangRate() {
		return exchangRate;
	}
	public void setExchangRate(String exchangRate) {
		this.exchangRate = exchangRate;
	}
	public String getCommonAddr() {
		return commonAddr;
	}
	public void setCommonAddr(String commonAddr) {
		this.commonAddr = commonAddr;
	}
}
