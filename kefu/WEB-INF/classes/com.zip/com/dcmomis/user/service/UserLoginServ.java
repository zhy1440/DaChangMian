package com.dcmomis.user.service;

import java.io.*;
import java.sql.*;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.*;

import com.dcmomis.user.CustomerInfoBean;
import com.dcmomis.utils.*;

public class UserLoginServ extends HttpServlet {
	// execute GET request
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String userName = "�����µ�¼";
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String uid = (String) request.getParameter("uid");
		if (!uid.equals("undefined")) {
			userName = getUserName(uid);
		}

		System.out.println(userName);
		out.print(userName);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		// doGet(request, response);
		PrintWriter out = response.getWriter();
		out.print("Hello");
		System.out.println("Hello");
	}

	public String getUserName(String uid) {
		Connection conn = null;
		Statement stm = null;
		ResultSet result = null;
		String userName = null;
		String queryString = "SELECT m.username FROM pre_common_member m WHERE m.uid = " + uid;
		try {
			conn = DcmDBUtils.getDBConnection();
			stm = conn.createStatement();
			result = stm.executeQuery(queryString);

			while (result.next()) {
				userName = result.getString("username");
			}
			return userName;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DcmDBUtils.release(stm, result, conn);
		}
		return null;
	}
}
