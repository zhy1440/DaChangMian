/**
 * This view is for customer to place an order.
 */
Ext.define('MyApp.view.customer.OrderPlace', {
    extend: 'Ext.form.FormPanel',
    xtype: 'orderplace',
    ui: 'dark',
    requires: [
        'MyApp.store.Personnel'
    ],
title: '下单',
defaultType: 'textfield',
buttonAlign: 'center',
frame: true,
fieldDecfaults:{
  labelAlign:'right',
  labelWidth: 70
},
items: [{
    id: 'LiBaId',
    fieldLabel:'篱笆号'
  },{

    fieldLabel:'商品名称',
    allowBlank: false
  },{
    fieldLabel:'单价',
    allowBlank: false
  },{
    fieldLabel:'数量',
    allowBlank: false
  },{
    fieldLabel:'折扣'
  },{
    fieldLabel:'尺寸'
  },{
    fieldLabel:'颜色'
  },{
    fieldLabel: '网站链接',
    allowBlank: false
  },{
    fieldLabel:'备注'
  },{
    fieldLabel: '上传图片'
  }],
buttons: [{
  id: 'okOrder',
  text:'确认下单'
},{
  id: 'reset',
  text: '重置'
}]
});
