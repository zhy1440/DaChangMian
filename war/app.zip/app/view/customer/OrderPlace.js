/**
 * This view is for customer to place an order.
 */
Ext
		.define(
				'app.view.customer.OrderPlace',
				{
					extend : 'Ext.form.FormPanel',
					xtype : 'orderplace',
					requires : [ 'app.view.customer.OrderPlaceController' ],
					controller : 'orderPlace',

					// The form will submit an AJAX request to this URL when
					// submitted
					// url: './OrderOperation?action=placeOrderRecord',

					ui : 'dark',
					title : '下单',
					defaultType : 'textfield',
					buttonAlign : 'center',
					frame : true,
					fieldDecfaults : {
						labelAlign : 'right',
						labelWidth : 70
					},
					items : [ {
						name : 'cstId',
						fieldLabel : '篱笆号',
						editable : false,
						disable : true,
						value : localStorage.getItem("LoggedInUserName")
					}, {
						name : 'link',
						fieldLabel : '网站链接',
						allowBlank : false
					}, {
						name : 'commodityName',
						fieldLabel : '商品名称',
						allowBlank : false
					}, {
						name : 'unitPrice',
						fieldLabel : '单价',
						allowBlank : false
					}, {
						name : 'amount',
						fieldLabel : '数量',
						allowBlank : false
					}, {
						name : 'goodsColor',
						fieldLabel : '颜色',
						allowBlank : false
					}, {
						name : 'goodsSize',
						fieldLabel : '尺寸',
						allowBlank : false
					}, {
						name : 'discount1',
						fieldLabel : '折扣'
					}, {
						name : 'comments',
						fieldLabel : '备注'
					}, {
						name : 'picture',
						fieldLabel : '上传图片',
						allowBlank : false
					} ],
					buttons : [
							{
								id : 'okOrder',
								text : '确认下单',
								formBind : true, // only enabled once the form is valid
								handler : 'onOkOrderClick'
							}, {
								id : 'reset',
								text : '重置',
								handler : 'onResetClick'
							} ]
				});
