/**
 * This class is the controller for the main view for the application. It is
 * specified as the "controller" of the Main view class.
 * 
 * TODO - Replace this content of this view to suite the needs of your
 * application.
 */
Ext
		.define(
				'app.view.customer.OrderPlaceController',
				{
					extend : 'Ext.app.ViewController',

					alias : 'controller.orderPlace',

					onOkOrderClick : function(sender, record) {
						Ext.Msg.confirm('Confirm', 'Are you sure?',
								'onConfirm', this);
					},
					onResetClick : function(sender, record) {
						this.getView().getForm().reset();
					},
					OkRenewClick : function(sender, record) {
						Ext.Msg.confirm('Confirm', 'Are you sure?',
								'onConfirm', this);
					},

					onConfirm : function(choice) {
						if (choice === 'yes') {
							var form = this.getView().getForm();
							var param = form.getFieldValues();

							if (form.isValid()) {
								form
										.submit({
											url : './OrderOperation?action=placeOrderRecord',
											method : 'POST',
											waitMsg : 'Submitting your data...',
											 params : param,
											success : function(form, action) {
												// server responded with
												// success = true
												var result = action.result.successMsg;
												Ext.Msg.show({
												    title:'提交成功',
												    message: result,
												    buttons: Ext.Msg.YESNO,
												    icon: Ext.Msg.QUESTION,
												    fn: function(btn) {
												        if (btn === 'yes') {
												            console.log('go to my orders');
												            Ext.getCmp('customermain').setActiveTab(0);
												            //window.location='./index.jsp';
												        } else if (btn === 'no') {
												            console.log('No pressed');
												        } 
												    }
												});
											},
											failure : function(form, action) {
												if (action.failureType === Ext.form.action.Action.CONNECT_FAILURE) {
													Ext.Msg
															.alert(
																	'Error',
																	'Status:'
																			+ action.response.status
																			+ ': '
																			+ action.response.statusText);
												}
												if (action.failureType === Ext.form.action.Action.SERVER_INVALID) {
													// server responded with success =  false
													Ext.Msg
															.alert(
																	'Invalid',
																	action.result.errorMsg);
												}
											}
										});
							}
						}
					},
					onMyOder:function(){
						
					},
					onGoOn:function(){
						
					}
				});
