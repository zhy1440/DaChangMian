/**
 * This class is the main view for the application. It is specified in app.js as
 * the "mainView" property. That setting automatically applies the "viewport"
 * plugin causing this view to become the body element (i.e., the viewport).
 * 
 * TODO - Replace this content of this view to suite the needs of your
 * application.
 */
Ext.define('app.view.main.CustomerMain', {
	extend : 'Ext.tab.Panel',
	xtype : 'app-customermain',

	requires : [ 'Ext.plugin.Viewport', 'Ext.window.MessageBox',
			'app.view.main.CustomerMainController', 'app.view.main.MainModel',
			'app.view.main.List' ],

	controller : 'customermain',
	viewModel : 'main',
	plugins: 'viewport',
	
	ui : 'navigation',

	tabBarHeaderPosition : 1,
	titleRotation : 0,
	tabRotation : 0,
	id:'customermain',
	
	header : {
		layout : {
			align : 'stretchmax'
		},
		title : {
			bind : {
				text : '{name}'
			},
			flex : 0
		},
		iconCls : 'fa-th-list',
		items : [ {
			xtype : 'label',
			text : "您好，" + localStorage.getItem("LoggedInUserName"),
			margin : '10 0'
		} ]
	},

	tabBar : {
		flex : 1,
		layout : {
			align : 'stretch',
			overflowHandler : 'none'
		}
	},

	responsiveConfig : {
		tall : {
			headerPosition : 'top'
		},
		wide : {
			headerPosition : 'left'
		}
	},

	defaults : {
		bodyPadding : 20,
		tabConfig : {
			plugins : 'responsive',
			responsiveConfig : {
				wide : {
					iconAlign : 'left',
					textAlign : 'left'
				},
				tall : {
					iconAlign : 'top',
					textAlign : 'center',
					width : 120
				}
			}
		},
		autoScroll : true
	},

	items : [
	/*
	 * { iconCls : 'fa-home', bind : { title : '{menu.order_input}' }, // The
	 * following grid shares a store with the classic version's grid as // well!
	 * items : [ { xtype : 'mainlist' } ] },
	 */
	{
		iconCls : 'fa-cog',
		bind : {
			//html : '{loremIpsum}',
			title : '{cstMenu.cst_order_management}'
		},
		items : [ {
			xtype : 'ordermanagement'
		} ]
	}, {
		iconCls : 'fa-cog',
		bind : {
			html : '{loremIpsum}',
			title : '{cstMenu.cst_my_info}'
		}
	}, {
		iconCls : 'fa-cog',
		bind : {
			// html: '{loremIpsum}',
			title : '{cstMenu.cst_order_place}'

		},
		items : [ {
			xtype : 'orderplace'
		} ]
	} ],
	listeners:{// 添加监听器，点击此页面的tab时候要重新加载（刷新功能）
     	activate:function(){
      	this.getUpdater().refresh(); 
     	}
	}
});
